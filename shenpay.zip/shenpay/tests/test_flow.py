"""Uji semua fitur dengan Telegram, Digiflazz, supplier cadangan, dan Tripay tiruan (tanpa internet).
Jalankan: python -m pytest tests -q
"""
import hashlib
import hmac
import json
import os
import sys
import tempfile
import threading
import urllib.error
import urllib.parse
import urllib.request

TMP = tempfile.mkdtemp()
os.environ.update({
    "TELEGRAM_TOKEN": "TEST", "ADMIN_IDS": "1", "DIGIFLAZZ_USERNAME": "user", "DIGIFLAZZ_API_KEY": "key",
    "DIGIFLAZZ_WEBHOOK_SECRET": "rahasia", "TRIPAY_API_KEY": "tk", "TRIPAY_PRIVATE_KEY": "priv",
    "TRIPAY_MERCHANT_CODE": "T123", "PUBLIC_URL": "https://contoh.up.railway.app",
    "DB_PATH": os.path.join(TMP, "t.db"), "MARKUP_FLAT": "1000", "MARKUP_RESELLER": "700", "MARKUP_AGEN": "400",
    "MARKUP_PERCENT": "0", "KOMISI_UPLINE": "100", "PASCA_MARKUP": "2500",
    "SUPPLIER2_NAME": "Cadangan", "SUPPLIER2_URL": "http://s2.local/trx?product={product}&dest={dest}&refID={ref}"
                                                   "&memberID={memberid}&pin={pin}&password={password}",
    "SUPPLIER2_MEMBERID": "M01", "SUPPLIER2_PIN": "1111", "SUPPLIER2_PASSWORD": "pw", "SUPPLIER2_SECRET": "s2rahasia",
    "SUPPLIER2_BALANCE_URL": "http://s2.local/saldo?memberID={memberid}&pin={pin}&password={password}",
})
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest  # noqa: E402

import bot  # noqa: E402
import config  # noqa: E402
import db  # noqa: E402
import jobs  # noqa: E402
import net  # noqa: E402
import reseller_api  # noqa: E402
import server  # noqa: E402
import service  # noqa: E402

config.BOT_USERNAME = "TesPulsaBot"


def item(name, cat, brand, price, sku, ok=True, **kw):
    d = {"product_name": name, "category": cat, "brand": brand, "price": price, "buyer_sku_code": sku,
         "buyer_product_status": True, "seller_product_status": ok, "unlimited_stock": True, "stock": 0, "desc": "-"}
    d.update(kw)
    return d


PRICELIST = [
    item("Telkomsel 10.000", "Pulsa", "TELKOMSEL", 10150, "T10"),
    item("Telkomsel 5.000", "Pulsa", "TELKOMSEL", 5200, "T5"),
    item("XL 10.000", "Pulsa", "XL", 10300, "X10"),
    item("XL Gangguan", "Pulsa", "XL", 20000, "X20", ok=False),
    item("Telkomsel Data 5GB", "Data", "TELKOMSEL", 30000, "TD5", desc="5GB 30 hari"),
    item("PLN 20.000", "PLN", "PLN", 20100, "PLN20"),
    item("DANA 25.000", "E-Money", "DANA", 25150, "DANA25"),
    item("Free Fire 70 Diamond", "Games", "FREE FIRE", 9500, "FF70"),
    item("Voucher Lain", "Voucher", "X", 5000, "V5"),
]
PASCA = [{"product_name": "PLN Pascabayar", "category": "Pascabayar", "brand": "PLN PASCABAYAR", "admin": 2500,
          "buyer_sku_code": "PLNPASCA", "buyer_product_status": True, "seller_product_status": True, "desc": "-"},
         {"product_name": "BPJS Kesehatan", "category": "Pascabayar", "brand": "BPJS KESEHATAN", "admin": 2500,
          "buyer_sku_code": "BPJS", "buyer_product_status": True, "seller_product_status": True, "desc": "-"}]


class Fake:
    def __init__(self):
        self.sent, self.uploads, self.trx_calls, self.s2_calls, self.callbacks = [], [], [], [], []
        self.trx_mode, self.s2_mode = {}, {}
        self.tripay_status = "UNPAID"
        self.mid = 100

    # --- JSON API ---
    def request(self, method, url, data=None, headers=None, timeout=40):
        if "api.telegram.org" in url:
            self.sent.append((url.rsplit("/", 1)[1], data))
            self.mid += 1
            return {"ok": True, "result": {"message_id": self.mid}}
        if url.endswith("/price-list"):
            assert data["sign"] == hashlib.md5(b"userkeypricelist").hexdigest()
            return {"data": PASCA if data["cmd"] == "pasca" else PRICELIST}
        if url.endswith("/cek-saldo"):
            return {"data": {"deposit": 250000}}
        if url.endswith("/inquiry-pln"):
            return {"data": {"name": "BUDI", "segment_power": "R1/900"}}
        if url.endswith("/transaction") and "digiflazz" in url:
            assert data["sign"] == hashlib.md5(("userkey" + data["ref_id"]).encode()).hexdigest()
            self.trx_calls.append(data)
            cmd = data.get("commands")
            if cmd == "inq-pasca":
                return {"data": {"ref_id": data["ref_id"], "status": "Sukses", "rc": "00", "customer_name": "SITI",
                                 "price": 152500, "message": "Inquiry sukses"}}
            if cmd in ("pay-pasca", "status-pasca"):
                return {"data": {"ref_id": data["ref_id"], "status": "Sukses", "rc": "00", "customer_name": "SITI",
                                 "price": 152500, "sn": "PAS-SN-1", "message": "Pembayaran sukses"}}
            mode = self.trx_mode.get(data["customer_no"], "Sukses")
            if mode == "neterror":
                raise net.NetError("timeout")
            rc = {"Sukses": "00", "Pending": "03", "Gagal": "02", "Salah": "54"}[mode]
            status = "Gagal" if mode == "Salah" else mode
            return {"data": {"ref_id": data["ref_id"], "status": status, "rc": rc,
                             "sn": "SN123" if status == "Sukses" else "", "message": f"Transaksi {mode}"}}
        if url.endswith("/transaction/create"):
            return {"success": True, "data": {"reference": "TRP" + data["merchant_ref"], "amount": data["amount"] + 750,
                                              "qr_url": "https://tripay/qr.png", "checkout_url": "https://tripay/c"}}
        if "/transaction/detail" in url:
            return {"success": True, "data": {"status": self.tripay_status}}
        raise AssertionError("URL tak terduga: " + url)

    # --- teks: supplier cadangan & callback reseller ---
    def request_text(self, method, url, data=None, headers=None, timeout=40):
        if url.startswith("http://s2.local/trx"):
            q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url).query))
            self.s2_calls.append(q)
            mode = self.s2_mode.get(q["dest"], "Sukses")
            return {"Sukses": f"R#{q['refID']} {q['product']}.{q['dest']} SUKSES. SN: S2SN999",
                    "Gagal": f"R#{q['refID']} GAGAL, stok kosong",
                    "Pending": f"R#{q['refID']} sedang diproses"}[mode]
        if url.startswith("http://s2.local/saldo"):
            return "Saldo Anda Rp1.234.000"
        if url.startswith("https://reseller.example"):
            self.callbacks.append((data, headers))
            return "OK"
        raise AssertionError("URL teks tak terduga: " + url)

    def upload(self, url, fields, file_field, filename, content, content_type, timeout=60):
        self.uploads.append((url.rsplit("/", 1)[1], fields, filename, content))
        return {"ok": True, "result": {"message_id": 1}}

    # --- helper ---
    def texts(self, chat=None):
        return [p.get("text") or p.get("caption") for m, p in self.sent
                if m in ("sendMessage", "editMessageText", "sendPhoto") and (chat is None or p["chat_id"] == chat)]

    def last(self, chat=None):
        return self.texts(chat)[-1]

    def last_kb(self):
        for m, p in reversed(self.sent):
            if p and p.get("reply_markup") and "inline_keyboard" in p["reply_markup"]:
                return p["reply_markup"]["inline_keyboard"]


@pytest.fixture()
def fake(monkeypatch):
    f = Fake()
    monkeypatch.setattr(net, "request", f.request)
    monkeypatch.setattr(net, "request_text", f.request_text)
    monkeypatch.setattr(net, "upload", f.upload)
    monkeypatch.setattr(reseller_api, "_spawn", lambda fn: fn())
    c = db.conn()
    for t in [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite%'")]:
        c.execute(f"DROP TABLE {t}")
    db.init()
    bot._sessions.clear()
    service.sync_products()
    return f


UID, UP = 555, 777


def msg(text, uid=UID):
    bot.handle_update({"message": {"message_id": 9, "chat": {"id": uid, "type": "private"},
                                   "from": {"id": uid, "first_name": "Andi"}, "text": text}})


def click(data, uid=UID, mid=1):
    bot.handle_update({"callback_query": {"id": "c", "from": {"id": uid, "first_name": "Andi"},
                                          "data": data, "message": {"message_id": mid}}})


def find_btn(kb, contains):
    for row in kb:
        for b in row:
            if contains in b["text"]:
                return b.get("callback_data")
    raise AssertionError(f"tombol '{contains}' tidak ada: {kb}")


def member(uid=UID, saldo=0, pin=None, level=None):
    msg("/start", uid)
    if saldo:
        db.change_balance(uid, saldo, "admin")
    if pin:
        db.set_pin(uid, pin)
    if level:
        db.set_level(uid, level)


def start_http():
    httpd = server.make_server(0)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd, httpd.server_address[1]


def http(port, method, path, data=None, headers=None, cookie=None):
    headers = dict(headers or {})
    if cookie:
        headers["Cookie"] = cookie
    body = data
    if isinstance(data, dict):
        body = urllib.parse.urlencode(data).encode()
        headers.setdefault("Content-Type", "application/x-www-form-urlencoded")

    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a, **k):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=body, headers=headers, method=method)
    try:
        r = opener.open(req)
        return r.status, dict(r.headers), r.read().decode()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read().decode()


# =============== katalog & harga ===============
def test_sync_katalog_dan_harga_level(fake):
    assert db.count_products() == 9  # 7 prabayar aktif + 2 tagihan (gangguan & kategori lain dibuang)
    t10 = db.product_by_code("t10")  # kode tidak peka huruf besar/kecil
    assert db.sell_price(t10["base_price"], "member") == 11200
    assert db.sell_price(t10["base_price"], "reseller") == 10900
    assert db.sell_price(t10["base_price"], "agen") == 10600
    assert db.brands("Pascabayar") == ["BPJS KESEHATAN", "PLN PASCABAYAR"]


# =============== beli lewat tombol ===============
def test_beli_tanpa_pin_dan_struk(fake):
    member(saldo=50000)
    msg("📱 Pulsa")
    msg("+62 812-3456-7890")
    assert "TELKOMSEL" in fake.last()
    assert "XL" not in json.dumps(fake.last_kb())
    click(find_btn(fake.last_kb(), "Telkomsel 10.000"))
    assert "Konfirmasi" in fake.last() and "T10.081234567890.PIN" in fake.last()
    click(find_btn(fake.last_kb(), "Beli Sekarang"))
    assert "Sukses" in fake.last() and "SN123" in fake.last() and "/pin" in fake.last()
    assert db.balance(UID) == 50000 - 11200
    assert fake.trx_calls[-1]["max_price"] == 11200 and fake.trx_calls[-1]["testing"] is True
    ref = db.user_trx(UID)[0]["ref_id"]
    click(f"st:{ref}")
    method, fields, fname, png = fake.uploads[-1]
    assert method == "sendPhoto" and png[:8] == b"\x89PNG\r\n\x1a\n" and len(png) > 3000
    m = db.mutations(UID)
    assert m[0]["kind"] == "trx" and m[0]["delta"] == -11200 and m[0]["balance_after"] == 38800


def test_beli_dengan_pin(fake):
    member(saldo=50000, pin="123456")
    msg("📱 Pulsa")
    msg("081234567890")
    click(find_btn(fake.last_kb(), "Telkomsel 10.000"))
    click(find_btn(fake.last_kb(), "Beli Sekarang"))
    assert "PIN" in fake.last()
    assert not fake.trx_calls
    msg("111111")
    assert "PIN salah" in fake.last()
    assert ("deleteMessage", {"chat_id": UID, "message_id": 9}) in fake.sent
    msg("123456")
    assert "Sukses" in fake.last()
    assert db.balance(UID) == 38800


def test_pin_terkunci_setelah_5_salah(fake):
    member(pin="123456")
    for _ in range(5):
        assert db.check_pin(UID, "000000") in ("wrong", "locked")
    assert db.check_pin(UID, "123456") == "locked"


def test_atur_pin_lewat_bot(fake):
    member()
    msg("/pin")
    msg("12345")
    assert "6 angka" in fake.last()
    msg("654321")
    msg("654321")
    assert "berhasil" in fake.last()
    assert db.check_pin(UID, "654321") == "ok"


def test_klik_dobel_hanya_sekali(fake):
    member(saldo=50000)
    msg("📱 Pulsa")
    msg("081234567890")
    click(find_btn(fake.last_kb(), "Telkomsel 10.000"))
    ok = find_btn(fake.last_kb(), "Beli Sekarang")
    click(ok)
    click(ok)
    assert len(fake.trx_calls) == 1 and db.balance(UID) == 38800


def test_harga_reseller_lebih_murah(fake):
    member(saldo=50000, level="reseller")
    msg("📱 Pulsa")
    msg("081234567890")
    assert "Rp10.900" in json.dumps(fake.last_kb())
    click(find_btn(fake.last_kb(), "Telkomsel 10.000"))
    click(find_btn(fake.last_kb(), "Beli Sekarang"))
    assert db.balance(UID) == 50000 - 10900


def test_saldo_kurang(fake):
    member()
    msg("📱 Pulsa")
    msg("081234567890")
    click(find_btn(fake.last_kb(), "Telkomsel 10.000"))
    assert "Saldo kurang" in fake.last()
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert not ok and "Saldo tidak cukup" in text and db.balance(UID) == 0


# =============== multi-supplier ===============
def test_failover_ke_supplier_cadangan(fake):
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400)  # lebih mahal -> cadangan
    fake.trx_mode["081234567890"] = "Gagal"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    t = db.get_trx(t["ref_id"])
    assert t["status"] == "Sukses" and t["supplier"] == "cadangan" and t["sn"] == "S2SN999"
    assert t["tried"] == "digiflazz,cadangan" and t["base_price"] == 10400
    assert fake.s2_calls[-1]["product"] == "S2T10" and fake.s2_calls[-1]["refID"].endswith("-2")
    assert db.balance(UID) == 50000 - 11200


def test_supplier_termurah_dipakai_duluan(fake):
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 9900)
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert db.get_trx(t["ref_id"])["supplier"] == "cadangan" and not fake.trx_calls


def test_nomor_salah_tidak_failover_dan_refund(fake):
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400)
    fake.trx_mode["081299999999"] = "Salah"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081299999999")
    assert db.get_trx(t["ref_id"])["status"] == "Gagal" and not fake.s2_calls
    assert db.balance(UID) == 50000


def test_semua_supplier_gagal_refund(fake):
    db.set_setting("auto_retry", 0)
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400)
    fake.trx_mode["081234567890"] = "Gagal"
    fake.s2_mode["081234567890"] = "Gagal"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert db.get_trx(t["ref_id"])["status"] == "Gagal" and "dikembalikan" in text
    assert db.balance(UID) == 50000
    assert [m["kind"] for m in db.mutations(UID)][:2] == ["refund", "trx"]


def test_supplier_dinonaktifkan_admin(fake):
    member(saldo=50000)
    member(uid=1)
    db.set_supplier_price("cadangan", "T10", "S2T10", 9900)
    click("adm:tog:cadangan", uid=1)
    assert "nonaktif" in fake.last(1)
    service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert not fake.s2_calls and fake.trx_calls


def test_laporan_h2h_supplier_cadangan(fake):
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 9900)
    fake.s2_mode["081234567890"] = "Pending"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert "Pending" in text
    httpd, port = start_http()
    try:
        q = urllib.parse.urlencode({"refid": t["ref_id"], "message": "SUKSES SN: ABCD1234"})
        assert http(port, "GET", f"/callback/h2h/salah?{q}")[0] == 403
        assert http(port, "GET", f"/callback/h2h/s2rahasia?{q}")[0] == 200
        t = db.get_trx(t["ref_id"])
        assert t["status"] == "Sukses" and t["sn"] == "ABCD1234"
    finally:
        httpd.shutdown()


# =============== downline & komisi ===============
def test_komisi_upline(fake):
    member(uid=UP)
    msg(f"/start ref_{UP}", uid=UID)
    assert db.get_user(UID)["upline_id"] == UP
    assert any("Downline baru" in t for t in fake.texts(UP))
    db.change_balance(UID, 50000, "admin")
    service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert db.balance(UP) == 100 and db.commission_total(UP) == 100
    fake.trx_mode["081700000000"] = "Gagal"
    service.buy(UID, db.product_by_code("X10"), "081700000000")
    assert db.balance(UP) == 100  # gagal = tidak ada komisi
    msg("👥 Downline", uid=UP)
    assert "start=ref_777" in fake.last(UP) and "Rp100" in fake.last(UP)
    assert db.stats(0)["laba"] == 11200 - 10150 - 100


def test_tidak_bisa_jadi_upline_sendiri(fake):
    msg(f"/start ref_{UID}")
    assert db.get_user(UID)["upline_id"] is None


# =============== format cepat ===============
def test_format_cepat(fake):
    member(saldo=50000)
    msg("T10.081234567890.123456")
    assert "butuh PIN" in fake.last()
    db.set_pin(UID, "123456")
    msg("T10.081234567890.999999")
    assert "PIN salah" in fake.last()
    msg("t10.6281234567890.123456")
    assert "Sukses" in fake.last() and fake.trx_calls[-1]["customer_no"] == "081234567890"
    msg("T10.081234567890.123456")
    assert "sudah ada 5 menit" in fake.last() and len(fake.trx_calls) == 1
    msg("T10.081234567890.123456.2")
    assert "Sukses" in fake.last() and len(fake.trx_calls) == 2
    msg("ZZZ.081234567890.123456")
    assert "tidak ditemukan" in fake.last()
    msg("HRG.telkomsel")
    assert "<code>T10</code>" in fake.last() and "Rp11.200" in fake.last()
    msg("SAL")
    assert "Rp27.600" in fake.last()


# =============== tagihan ===============
def test_tagihan_lewat_tombol(fake):
    member(saldo=200000)
    msg("🧾 Tagihan")
    click(find_btn(fake.last_kb(), "PLN PASCABAYAR"))
    assert "nomor pelanggan" in fake.last()
    msg("532100000001")
    assert "SITI" in fake.last() and "Rp155.000" in fake.last()  # 152.500 + 2.500
    click(find_btn(fake.last_kb(), "Bayar"))
    assert "Sukses" in fake.last() and "PAS-SN-1" in fake.last()
    assert db.balance(UID) == 200000 - 155000
    cmds = [c.get("commands") for c in fake.trx_calls]
    assert cmds == ["inq-pasca", "pay-pasca"] and fake.trx_calls[0]["ref_id"] == fake.trx_calls[1]["ref_id"]
    ref = fake.trx_calls[0]["ref_id"]
    click(f"pay:{ref}")  # tidak bisa bayar dua kali
    assert db.balance(UID) == 45000


def test_tagihan_format_cepat(fake):
    member(saldo=200000, pin="123456", level="agen")
    msg("CEK.BPJS.0001234567")
    assert "Rp154.400" in fake.last()  # 152.500 + (2.500 - (1.000 - 400))
    ref = fake.trx_calls[-1]["ref_id"]
    msg(f"BAYAR.{ref}.123456")
    assert "Sukses" in fake.last()
    assert db.balance(UID) == 200000 - 154400


def test_game_dan_ewallet(fake):
    member(saldo=100000)
    msg("🎮 Game")
    click(find_btn(fake.last_kb(), "FREE FIRE"))
    msg("12345678 1234")
    click(find_btn(fake.last_kb(), "Free Fire"))
    click(find_btn(fake.last_kb(), "Beli Sekarang"))
    assert fake.trx_calls[-1]["customer_no"] == "123456781234"
    msg("💳 E-Wallet")
    click(find_btn(fake.last_kb(), "DANA"))
    msg("085712345678")
    click(find_btn(fake.last_kb(), "DANA 25.000"))
    click(find_btn(fake.last_kb(), "Beli Sekarang"))
    assert fake.trx_calls[-1]["buyer_sku_code"] == "DANA25"


def test_pending_lalu_webhook_dan_cek_ulang(fake):
    db.set_setting("auto_retry", 0)
    member(saldo=50000)
    fake.trx_mode["081234567890"] = "Pending"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert "Pending" in text
    httpd, port = start_http()
    try:
        body = json.dumps({"data": {"ref_id": t["ref_id"], "status": "Sukses", "sn": "SNOK"}}).encode()
        assert http(port, "POST", "/callback/digiflazz", body, {"X-Hub-Signature": "sha1=x"})[0] == 403
        sig = "sha1=" + hmac.new(b"rahasia", body, hashlib.sha1).hexdigest()
        assert http(port, "POST", "/callback/digiflazz", body, {"X-Hub-Signature": sig})[0] == 200
        assert http(port, "POST", "/callback/digiflazz", body, {"X-Hub-Signature": sig})[0] == 200
        assert db.get_trx(t["ref_id"])["status"] == "Sukses"
        assert sum("SNOK" in x for x in fake.texts(UID)) == 1
    finally:
        httpd.shutdown()
    fake.trx_mode["081234567890"] = "neterror"
    ok, text, t2 = service.buy(UID, db.product_by_code("T10"), "081234567890")
    assert db.get_trx(t2["ref_id"])["status"] == "Pending"
    fake.trx_mode["081234567890"] = "Gagal"
    db.conn().execute("UPDATE transactions SET created_at = created_at - 120")
    service.recheck_pending()
    assert db.get_trx(t2["ref_id"])["status"] == "Gagal" and db.balance(UID) == 50000 - 11200


# =============== API H2H reseller ===============
def api(port, action, body):
    code, _, text = http(port, "POST", f"/api/v1/{action}", json.dumps(body).encode(),
                         {"Content-Type": "application/json"})
    return code, json.loads(text)


def test_api_reseller(fake):
    db.set_setting("auto_retry", 0)
    member(saldo=300000, level="agen")
    msg("/apikey")
    key = db.get_user(UID)["api_key"]
    assert key in fake.last()
    db.set_user_field(UID, "api_callback", "https://reseller.example/cb")
    sign = lambda x: hashlib.md5(f"{UID}{key}{x}".encode()).hexdigest()  # noqa: E731
    httpd, port = start_http()
    try:
        assert api(port, "cek-saldo", {"username": UID, "sign": "salah"})[0] == 401
        assert api(port, "cek-saldo", {"username": UID, "sign": sign("depo")})[1]["data"]["deposit"] == 300000
        pl = api(port, "price-list", {"username": UID, "sign": sign("pricelist")})[1]["data"]
        assert next(p for p in pl if p["buyer_sku_code"] == "T10")["price"] == 10600
        code, r = api(port, "transaction", {"username": UID, "buyer_sku_code": "T10", "customer_no": "081234567890",
                                            "ref_id": "INV1", "sign": sign("INV1")})
        assert r["data"]["status"] == "Sukses" and r["data"]["sn"] == "SN123" and r["data"]["ref_id"] == "INV1"
        assert r["data"]["buyer_last_saldo"] == 300000 - 10600
        code, r = api(port, "transaction", {"username": UID, "buyer_sku_code": "T10", "customer_no": "081234567890",
                                            "ref_id": "INV1", "sign": sign("INV1")})
        assert r["data"]["status"] == "Sukses" and len(fake.trx_calls) == 1  # ref sama = cek status
        # pending -> callback ke reseller dengan tanda tangan
        fake.trx_mode["081255555555"] = "Pending"
        code, r = api(port, "transaction", {"username": UID, "buyer_sku_code": "T10", "customer_no": "081255555555",
                                            "ref_id": "INV2", "sign": sign("INV2")})
        assert r["data"]["status"] == "Pending"
        t = db.get_trx_by_api_ref(UID, "INV2")
        service.webhook_result(t["supplier_ref"], {"status": "Gagal", "sn": "", "message": "Gangguan", "rc": "55",
                                                   "price": None})
        body, headers = fake.callbacks[-1]
        assert json.loads(body)["data"]["status"] == "Gagal" and json.loads(body)["data"]["ref_id"] == "INV2"
        assert headers["X-Hub-Signature"] == "sha1=" + hmac.new(key.encode(), body, hashlib.sha1).hexdigest()
        # tagihan via API
        code, r = api(port, "transaction", {"username": UID, "buyer_sku_code": "PLNPASCA", "customer_no": "5321",
                                            "ref_id": "TAG1", "sign": sign("TAG1"), "commands": "inq-pasca"})
        assert r["data"]["customer_name"] == "SITI" and r["data"]["price"] == 154400
        code, r = api(port, "transaction", {"username": UID, "buyer_sku_code": "PLNPASCA", "customer_no": "5321",
                                            "ref_id": "TAG1", "sign": sign("TAG1"), "commands": "pay-pasca"})
        assert r["data"]["status"] == "Sukses" and r["data"]["ref_id"] == "TAG1", r
        assert db.balance(UID) == 300000 - 10600 - 154400
        # IP whitelist
        db.set_user_field(UID, "api_ip", "9.9.9.9")
        assert api(port, "cek-saldo", {"username": UID, "sign": sign("depo")})[0] == 403
    finally:
        httpd.shutdown()


# =============== web panel ===============
def web_login(port, uid):
    code, headers, _ = http(port, "POST", "/login", {"tg_id": str(uid)})
    assert code == 303 and headers["Location"] == f"/login/kode?id={uid}"
    import re
    login_code = re.search(r"<code>(\d{6})</code>", fake_ref.last(uid)).group(1)
    assert http(port, "POST", "/login/kode", {"id": str(uid), "code": "000000"})[0] == 200
    code, headers, _ = http(port, "POST", "/login/kode", {"id": str(uid), "code": login_code})
    assert code == 303 and "HttpOnly" in headers["Set-Cookie"]
    return headers["Set-Cookie"].split(";")[0]


fake_ref = None


def test_web_panel(fake):
    global fake_ref
    fake_ref = fake
    member(saldo=50000)
    member(uid=1)
    service.buy(UID, db.product_by_code("T10"), "081234567890")
    httpd, port = start_http()
    try:
        assert http(port, "GET", "/panel")[0] == 303  # belum login
        assert http(port, "POST", "/login", {"tg_id": "999"})[2].count("belum terdaftar") == 1
        ck = web_login(port, UID)
        code, _, body = http(port, "GET", "/panel", cookie=ck)
        assert code == 200 and "Rp38.800" in body and "Telkomsel 10.000" in body
        assert "T10" in http(port, "GET", "/panel/harga?q=telkomsel", cookie=ck)[2]
        assert http(port, "GET", "/admin", cookie=ck)[0] == 303  # bukan admin
        import re
        csrf = re.search(r'name=csrf value="([^"]+)"', http(port, "GET", "/panel/api", cookie=ck)[2]).group(1)
        assert http(port, "POST", "/panel/api", {"action": "newkey", "csrf": "salah"}, cookie=ck)[0] == 403
        assert "API key baru" in http(port, "POST", "/panel/api", {"action": "newkey", "csrf": csrf}, cookie=ck)[2]
        assert db.get_user(UID)["api_key"]
        assert "Dokumentasi API" in http(port, "GET", "/docs/api")[2]

        ak = web_login(port, 1)
        for path in ("/admin", "/admin/trx", "/admin/members", "/admin/products", "/admin/settings"):
            code, _, body = http(port, "GET", path, cookie=ak)
            assert code == 200, path
        assert "<svg" in http(port, "GET", "/admin", cookie=ak)[2]
        acsrf = re.search(r'name=csrf value="([^"]+)"', http(port, "GET", "/admin/settings", cookie=ak)[2]).group(1)
        http(port, "POST", "/admin/settings", {"csrf": acsrf, "markup_member": "1500", "markup_reseller": "800",
                                               "markup_agen": "500", "markup_percent": "0", "komisi_upline": "150",
                                               "pasca_markup": "3000", "low_balance_alert": "100000"}, cookie=ak)
        assert db.sell_price(10150, "member") == 11700 and db.komisi() == 150
        http(port, "POST", "/admin/members", {"csrf": acsrf, "tg_id": str(UID), "action": "saldo", "amount": "+10000"},
             cookie=ak)
        http(port, "POST", "/admin/members", {"csrf": acsrf, "tg_id": str(UID), "action": "level", "level": "reseller"},
             cookie=ak)
        assert db.balance(UID) == 48800 and db.get_user(UID)["level"] == "reseller"
        http(port, "POST", "/admin/products", {"csrf": acsrf, "code": "T5", "action": "off"}, cookie=ak)
        assert db.product_by_code("T5")["admin_off"] == 1
        http(port, "POST", "/admin/products", {"csrf": acsrf, "code": "T10", "action": "s2", "sku": "ST10",
                                               "price": "10000"}, cookie=ak)
        assert db.supplier_options("T10")[0]["supplier"] == "cadangan"
        http(port, "GET", "/logout", cookie=ck)
        assert http(port, "GET", "/panel", cookie=ck)[0] == 303
    finally:
        httpd.shutdown()


# =============== deposit ===============
def test_deposit_qris(fake):
    member()
    msg("➕ Deposit")
    click(find_btn(fake.last_kb(), "Rp50.000"))
    ref = db.conn().execute("SELECT merchant_ref FROM deposits").fetchone()[0]
    httpd, port = start_http()
    try:
        body = json.dumps({"merchant_ref": ref, "status": "PAID"}).encode()
        h = {"X-Callback-Event": "payment_status", "X-Callback-Signature": "salah"}
        assert http(port, "POST", "/callback/tripay", body, h)[0] == 403
        h["X-Callback-Signature"] = hmac.new(b"priv", body, hashlib.sha256).hexdigest()
        assert http(port, "POST", "/callback/tripay", body, h)[0] == 200
        assert http(port, "POST", "/callback/tripay", body, h)[0] == 200
        assert db.balance(UID) == 50000 and db.mutations(UID)[0]["kind"] == "deposit"
    finally:
        httpd.shutdown()


# =============== admin, laporan, backup ===============
def test_admin_laporan_backup(fake):
    member(uid=1)
    member(saldo=50000)
    service.buy(UID, db.product_by_code("T10"), "081234567890")
    msg("/level 555 agen", uid=1)
    assert db.get_user(UID)["level"] == "agen" and "Agen" in fake.last(UID)
    msg("/markuplevel agen 300", uid=1)
    assert db.level_markup("agen") == 300
    msg("/laporan", uid=1)
    rep = fake.last(1)
    assert "Omzet" in rep and "Rp11.200" in rep and "digiflazz: Rp250.000" in rep and "cadangan: Rp1.234.000" in rep
    msg("/backup", uid=1)
    method, fields, fname, data = fake.uploads[-1]
    assert method == "sendDocument" and fname.endswith(".db.gz")
    import gzip
    assert gzip.decompress(data)[:15] == b"SQLite format 3"
    msg("/harga2 T5 S2T5 5000", uid=1)
    assert db.supplier_options("T5")[0]["supplier"] == "cadangan"
    msg("/cek " + db.user_trx(UID)[0]["ref_id"], uid=1)
    assert "Supplier: digiflazz" in fake.last(1)
    msg("/addsaldo 555 1000", uid=UID)
    assert db.balance(UID) == 38800  # member biasa tidak bisa


def test_peringatan_saldo_dan_harian(fake):
    member(uid=1)
    db.set_setting("low_balance_alert", 300000)
    jobs.check_low_balance()
    assert "menipis" in fake.last(1) and "digiflazz" in fake.last(1)
    n = len(fake.texts(1))
    jobs.check_low_balance()
    assert len(fake.texts(1)) == n  # tidak spam
    jobs.daily_tasks()
    assert len(fake.texts(1)) == n  # pertama kali menyala: tidak kirim
    db.set_setting("last_report_day", jobs.day_start() - 86400)
    jobs.daily_tasks()
    assert "Laporan Harian" in fake.last(1) and fake.uploads[-1][0] == "sendDocument"


def test_migrasi_database_lama(fake):
    """Database dari versi pertama tetap bisa dipakai."""
    path = os.path.join(TMP, "lama.db")
    import sqlite3
    c = sqlite3.connect(path)
    c.executescript("CREATE TABLE users (tg_id INTEGER PRIMARY KEY, name TEXT, username TEXT, balance INTEGER NOT NULL "
                    "DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL);"
                    "INSERT INTO users VALUES (5,'Lama',NULL,7000,0,1);"
                    "CREATE TABLE transactions (ref_id TEXT PRIMARY KEY, tg_id INTEGER NOT NULL, sku TEXT NOT NULL, "
                    "product TEXT NOT NULL, target TEXT NOT NULL, sell_price INTEGER NOT NULL, base_price INTEGER NOT NULL, "
                    "status TEXT NOT NULL, sn TEXT, message TEXT, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);")
    c.close()
    old = config.DB_PATH
    config.DB_PATH = path
    db._local.conn = None
    try:
        db.init()
        u = db.get_user(5)
        assert u["balance"] == 7000 and u["level"] == "member"
    finally:
        config.DB_PATH = old
        db._local.conn = None


# =============== kirim ulang otomatis & acc manual ===============
def _age(ref, sec=600):
    db.conn().execute("UPDATE transactions SET created_at=created_at-?, retry_at=0 WHERE ref_id=?", (sec, ref))


def test_kirim_ulang_otomatis_lalu_sukses(fake):
    member(saldo=50000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400)
    fake.trx_mode["081234567890"] = "Gagal"
    fake.s2_mode["081234567890"] = "Gagal"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    t = db.get_trx(t["ref_id"])
    assert t["status"] == "Pending" and t["retry_count"] == 1 and t["supplier"] is None
    assert "dicoba ulang otomatis" in text and db.balance(UID) == 50000 - 11200
    service.recheck_pending()  # belum waktunya
    assert len(fake.trx_calls) == 1
    fake.trx_mode["081234567890"] = "Sukses"
    _age(t["ref_id"])
    service.recheck_pending()
    t = db.get_trx(t["ref_id"])
    assert t["status"] == "Sukses" and fake.trx_calls[-1]["ref_id"] == t["ref_id"] + "-R1-1"
    assert any("SN123" in x for x in fake.texts(UID))


def test_kirim_ulang_tetap_gagal_lalu_refund_dan_notif_admin(fake):
    member(uid=1)
    member(saldo=50000)
    fake.trx_mode["081234567890"] = "Gagal"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    _age(t["ref_id"])
    service.recheck_pending()
    t = db.get_trx(t["ref_id"])
    assert t["status"] == "Gagal" and db.balance(UID) == 50000
    assert "Transaksi gagal" in fake.last(1) and "ax:re:" in json.dumps(fake.last_kb())


def test_acc_manual_dari_telegram(fake):
    member(uid=1)
    member(saldo=100000)
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400)
    fake.trx_mode["081234567890"] = "Pending"
    ok, text, t1 = service.buy(UID, db.product_by_code("T10"), "081234567890")
    ok, text, t2 = service.buy(UID, db.product_by_code("T10"), "081234567890")
    ok, text, t3 = service.buy(UID, db.product_by_code("T10"), "081234567890")
    for t in (t1, t2, t3):
        _age(t["ref_id"], 20 * 60)
    jobs.check_stuck()
    assert sum("Pending lebih dari 15 menit" in x for x in fake.texts(1)) == 3
    jobs.check_stuck()
    assert sum("Pending lebih dari 15 menit" in x for x in fake.texts(1)) == 3  # tidak diulang

    # 1) sukseskan manual dengan SN
    click(f"ax:ok:{t1['ref_id']}", uid=1)
    assert "Kirim <b>SN" in fake.last(1)
    msg("SNMANUAL777", uid=1)
    t = db.get_trx(t1["ref_id"])
    assert t["status"] == "Sukses" and t["sn"] == "SNMANUAL777" and t["handled_by"] == "admin:1"
    assert any("SNMANUAL777" in x for x in fake.texts(UID))

    # 2) gagalkan -> refund (dengan konfirmasi)
    bal = db.balance(UID)
    click(f"ax:fail:{t2['ref_id']}", uid=1)
    assert "Pastikan" in fake.last(1)
    click(f"ax:failok:{t2['ref_id']}", uid=1)
    assert db.get_trx(t2["ref_id"])["status"] == "Gagal" and db.balance(UID) == bal + 11200

    # 3) kirim ulang ke supplier lain
    fake.s2_mode["081234567890"] = "Sukses"
    click(f"ax:rsok:{t3['ref_id']}", uid=1)
    t = db.get_trx(t3["ref_id"])
    assert t["status"] == "Sukses" and t["supplier"] == "cadangan" and "dikirim ulang" in fake.last(1)

    # 4) proses ulang transaksi gagal -> transaksi baru, saldo dipotong lagi
    bal = db.balance(UID)
    fake.trx_mode["081234567890"] = "Sukses"
    db.set_supplier_price("cadangan", "T10", "S2T10", 10400, active=False)
    click(f"ax:reok:{t2['ref_id']}", uid=1)
    assert "Diproses ulang" in fake.last(1) and db.balance(UID) == bal - 11200
    assert "Admin memproses ulang" in fake.last(UID)

    # member biasa tidak bisa memakai tombol admin
    n = len(fake.sent)
    click(f"ax:failok:{t1['ref_id']}", uid=UID)
    assert db.get_trx(t1["ref_id"])["status"] == "Sukses"


def test_status_server_dan_laporan_error(fake):
    import logging
    member(uid=1)
    msg("/status", uid=1)
    assert "Status Server" in fake.last(1) and "Berjalan" in fake.last(1)
    h = jobs.AdminAlertHandler()
    h.setFormatter(logging.Formatter("%(message)s"))
    lg = logging.getLogger("uji")
    lg.addHandler(h)
    try:
        lg.error("Bug percobaan 123")
        lg.error("Bug kedua")
    finally:
        lg.removeHandler(h)
    bugs = [x for x in fake.texts(1) if "Error di server" in x]
    assert len(bugs) == 1 and "Bug percobaan 123" in bugs[0]


def test_acc_manual_dari_web(fake):
    global fake_ref
    fake_ref = fake
    member(uid=1)
    member(saldo=50000)
    fake.trx_mode["081234567890"] = "Pending"
    ok, text, t = service.buy(UID, db.product_by_code("T10"), "081234567890")
    httpd, port = start_http()
    try:
        ak = web_login(port, 1)
        import re
        page_ = http(port, "GET", "/admin/trx", cookie=ak)[2]
        assert "Pending (1)" in page_ and t["ref_id"] in page_
        csrf = re.search(r'name=csrf value="([^"]+)"', page_).group(1)
        body = http(port, "POST", "/admin/trx", {"csrf": csrf, "ref": t["ref_id"], "action": "ok", "sn": "WEBSN1"},
                    cookie=ak)[2]
        assert "disukseskan manual" in body
        assert db.get_trx(t["ref_id"])["sn"] == "WEBSN1"
    finally:
        httpd.shutdown()


def test_halaman_publik(fake):
    member(saldo=50000)
    service.buy(UID, db.product_by_code("T10"), "081234567890")
    httpd, port = start_http()
    try:
        code, _, body = http(port, "GET", "/")
        assert code == 200 and "Daftar lewat Telegram" in body and "t.me/TesPulsaBot" in body
        assert "0812•••••890" in body and "081234567890" not in body  # nomor disamarkan
        items = json.loads(http(port, "GET", "/ticker.json")[2])
        assert items[0]["t"] == "0812•••••890" and items[0]["p"] == "Telkomsel 10.000"
        code, _, body = http(port, "GET", "/harga?q=telkomsel")
        assert code == 200 and "Rp11.200" in body and "XL 10.000" not in body
        body = http(port, "GET", "/harga?k=Pascabayar")[2]
        assert "BPJS" in body and "Telkomsel" not in body
    finally:
        httpd.shutdown()


def test_banner_sambutan(fake):
    msg("/start")
    method, fields, fname, png = fake.uploads[-1]
    assert method == "sendPhoto" and fname == "selamat-datang.png" and png[:4] == b"\x89PNG"
    assert "Selamat datang" in fields["caption"] and "keyboard" in fields["reply_markup"]
